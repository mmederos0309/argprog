
//** cambio la escala sobre img HTML CSS JS  y Smile*/

const cambio = document.getElementById('cambio'); 
cambio.addEventListener('mouseenter', () => {
   cambio.style.transform = "scale(2)";
});

cambio.addEventListener('mouseleave', () => {
    cambio.style.transform = "scale(1)";
});

const cambio1 = document.getElementById('cambio1'); 
cambio1.addEventListener('mouseenter', () => {
    cambio1.style.transform = "scale(2)";
});

cambio1.addEventListener('mouseleave', () => {
    cambio1.style.transform = "scale(1)";
});

const cambio2 = document.getElementById('cambio2'); 
cambio2.addEventListener('mouseenter', () => {
    cambio2.style.transform = "scale(2)";
});

cambio2.addEventListener('mouseleave', () => {
    cambio2.style.transform = "scale(1)";
});

const smile = document.getElementById('smile'); 
smile.addEventListener('mouseenter', () => {
    smile.style.transform = "scale(2)";
});

smile.addEventListener('mouseleave', () => {
    smile.style.transform = "scale(1)";
});



/**  cambio mi nombre */


const element = document.getElementById('chelo');

element.addEventListener('mouseenter', () => {
    document.getElementById('chelo').innerHTML="Chelito!";
    element.style.fontSize="50px";
    element.style.color="red";
});

element.addEventListener('mouseleave', () => {
   document.getElementById('chelo').innerHTML="Marcelo Mederos";
   element.style.fontSize="30px";
   element.style.color="black";
   element.style.fontWeight="bold";
});



/** validar los campos del formulario */

function validar() {
    
    var nombre = document.getElementById("nombre").value;
    var email = document.getElementById('email').value;
    var mensaje = document.getElementById('mensaje').value;

    comparador = /\w+@\w+\.+[a-z]/;
      
    if ( nombre === "") {
        alert("Como te llamas?");
        return false;
    }

    else if (email === "") {
        alert("Sin e-mail, no voy a poder responder!");
        return false;
    }

    else if (!comparador.test(email)) {
        alert("El correo no es valido");
        return false;
    }

    else if (mensaje === "") {
        alert("y el mensaje..?");
        return false;
    }

    alert("Mensaje enviado, gracias!")
}



